<h1>Apache</h1>
<?php echo $_SERVER['SERVER_SOFTWARE']; ?><br><br>

Server name: <samp><?php echo $_SERVER['SERVER_NAME']; ?></samp><br>
Document root: <samp><?php echo $_SERVER['DOCUMENT_ROOT']; ?></samp><br>

<hr>

<h1>PHP</h1>
<?php echo 'Current PHP version: ' . phpversion(); ?>

<hr>

<h1>MySQL</h1>
<?php
#$mysqli = new mysqli(localhost, dbusername, dbuserpass [, database]);
$mysqli = new mysqli('localhost', 'root', 'root', '');

if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') '
            . $mysqli->connect_error);
}
echo '<p>Connection OK '. $mysqli->host_info.'<br>';
echo 'Server '.$mysqli->server_info.'</p>';
$mysqli->close();
?>