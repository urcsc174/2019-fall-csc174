<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Assignment 5a</title>
</head>
<body>

	<h1>Assignment 5 Demo - External Version</h1>
	<p>This version will process the HTML form in a <em>different file</em> (new.php), and that file writes the data to the database, then sends the user to another file (thanks.php) to see the confirmation message.</p>

	<form method="post" action="new.php">
		<label for="email">Email: </label>
		<input type="text" name="email" id="email">
		<input type="submit" value="Subscribe">
	</form>

</body>
</html>