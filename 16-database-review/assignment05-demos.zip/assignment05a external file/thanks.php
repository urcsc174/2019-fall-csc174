<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Assignment 5</title>
</head>
<body>

	<h1>Assignment 5 Thanks</h1>

	<p>That was lovely.  Good job.  <a href=".">Now go away.</a></p>

</body>
</html>