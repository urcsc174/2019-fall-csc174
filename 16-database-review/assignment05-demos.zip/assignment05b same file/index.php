<?php
include('connect-db.php');
if (isset($_POST['submit'])) {
	$email = mysqli_real_escape_string($connection, htmlspecialchars($_POST['email']));
	mysqli_query($connection, "INSERT INTO rkostin_newsletter (email) VALUES ('$email')");
	mysqli_close($connection);
	header("Location: thanks.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Assignment 5b</title>
</head>
<body>

	<h1>Assignment 5 Demo - Internal Version</h1>
	<p>This version will process the HTML form in the <em>same file</em> (this page), which sends the data to the database, then sends the user to another file (thanks.php) to see the confirmation message.</p>

	<form method="post" action="">
		<label for="email">Email: </label>
		<input type="text" name="email" id="email">
		<input type="submit" name="submit" value="Subscribe">
	</form>

</body>
</html>