<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Assignment 5c</title>
</head>
<body>

	<h1>Assignment 5 Demo - Ajax Version</h1>
	<p>This version uses Ajax (with jQuery) to send the data to an external file (new.php) and then swaps-out the HTML form with the confirmation message.</p>

	<div id="form-wrapper">
		<form method="post" action="" id="subscription-form">
			<label for="email">Email: </label>
			<input type="text" name="email" id="email">
			<input type="submit" name="submit" value="Subscribe">
		</form>
	</div>

<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<script>
$("#subscription-form").submit(function(e) {
	var formData = $("#subscription-form").serialize();
	$.ajax({
		type: 'POST',
		url: "new.php",
		data: formData,
		success: function(data){
			$("#form-wrapper").html("Thank you for subscribing!");
		}
	});
	e.preventDefault();
});
</script>
</body>
</html>