CREATE TABLE `emaillist` (
`id` int(11) NOT NULL auto_increment,
`firstName` varchar(50) NOT NULL,
`lastName` varchar(100) NOT NULL,
`email` varchar(100) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;