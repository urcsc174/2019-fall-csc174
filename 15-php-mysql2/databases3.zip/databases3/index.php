<?php
	// 1. Create a database connection
	require_once("config.php");

	// 2. Perform database query
	$query  = "SELECT * FROM emaillist";
	$result = mysqli_query($connection, $query);
?><!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Database Read</title>
	<style>
		body { 
			margin: 0 auto;
			width: 90%;
			max-width: 960px;
			display: grid; 
			grid-template-columns: 1fr 1fr;
		}
		nav {
			position: fixed;
			bottom: 15px;
			right: 15px;
			background-color: white;
		}
	</style>
</head>
<body>

	<section>

		<h1>Database Read</h1>

		<ul>
		<?php
			// 3. Use returned data (if any)
			while($data = mysqli_fetch_assoc($result)) {
		?>
			<li><?php echo $data["firstName"], " ", $data["lastName"], "<br><strong>", $data["email"], "</strong>"; ?></li>
		<?php } ?>
		</ul>

	</section>

<!-- reset the database pointer -->
<?php mysqli_data_seek($result,0); ?>

	<section>

		<h1>And again...</h1>

		<table border>
		  <tr>
		    <th>ID</th>
		    <th>First Name</th>
		    <th>Last Name</th>
		    <th>Email</th>
		  </tr>
		<?php
		// loop through results of database query, displaying them in the table
		while($row = mysqli_fetch_array( $result )) {
		?>
		  <tr>
		    <td><?php echo $row['id']; ?></td>
		    <td><?php echo $row['firstName']; ?></td>
		    <td><?php echo $row['lastName']; ?></td>
		    <td><?php echo $row['email']; ?></td>
		  </tr>
		<?php
		// close the loop
		}
		?>
		</table>

	</section>

	<nav>
		<ul>
			<li>View all the records</li>
			<li><a href="form_insert.html">Create a new record</a></li>
			<li><a href="form_delete.html">Delete a record</a></li>
		</ul>
	</nav>

</body>
</html>

<?php
	// 4. Release returned data
	mysqli_free_result($result);

	// 5. Close database connection
	mysqli_close($connection);
?>