<?php
	// 1. Create a database connection
	require_once("config.php");

	// This data is coming from HTML form values in $_POST
	$insertFirstName = $_POST["first"];
	$insertLastName = $_POST["last"];
	$insertEmail = $_POST["email"];

	// You really should escape all strings
	$insertFirstName = mysqli_real_escape_string($connection, $insertFirstName);
	$insertLastName = mysqli_real_escape_string($connection, $insertLastName);
	$insertEmail = mysqli_real_escape_string($connection, $insertEmail);
	
	// 2. Perform database query
	$query  = "INSERT INTO emaillist (firstName, lastName, email) VALUES ('$insertFirstName','$insertLastName ','$insertEmail')";
	$result = mysqli_query($connection, $query);

?><!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Database Insert</title>
	<style>
		body { 
			margin: 0 auto;
			width: 90%;
			max-width: 960px;
			display: grid; 
			grid-template-columns: 1fr 1fr;
		}
		nav {
			position: fixed;
			bottom: 15px;
			right: 15px;
			background-color: white;
		}
	</style>
</head>
<body>

	<section>

		<h1>Database Insert</h1>

<?php
	if ($result) {
		echo "Success! - the query seemed to work! (At least it didn't error-out.) <a href='index.php'>Return</a>";
?>
<?php
	} else {
		die("Database query failed.");
	}
?>

	</section>
	<nav>
		<ul>
			<li><a href="index.php">View all the records</a></li>
			<li><a href="form_insert.html">Create another new record</a></li>
			<li><a href="form_delete.html">Delete a record</a></li>
		</ul>
	</nav>
</body>
</html><?php
	// 4. Step 4 is unnecessary here because we didn't 
	//	  get data that needs to be released
	//mysqli_free_result($result);

	// 5. Close database connection
	mysqli_close($connection);
?>