<?php
	$dbhost = "localhost";
	$dbuser = "demo1";
	$dbpass = "coffee";
	$dbname = "demo1";
	$connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
?>